DO NOT REMOVE

This is a placeholder to allow for build rules putting public headers
in this directory. Using this directory allows us to ensure that our
public headers will work with external applications that make use of
Samba libraries
